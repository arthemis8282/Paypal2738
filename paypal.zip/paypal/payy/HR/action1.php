<?php
session_start();
include "anti/anti1.php";
include "anti/anti2.php";
include "anti/anti3.php";
include "anti/anti4.php";
include "anti/anti5.php";
include "anti/anti6.php";
include "anti/anti7.php";
error_reporting(0);
// action1.php
session_start();
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the user_email from the form
    $user_email = $_POST['EML'];

    // Print the user_email
    echo "User Email: " . $user_email;
} else {
    // If the form is not submitted, redirect to the login page or do something else
    header("Location: login.php"); // Replace 'login.php' with the actual login page URL
    exit();
}
?>